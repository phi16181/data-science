<!----- Conversion time: 1.271 seconds.


Using this Markdown file:

1. Cut and paste this output into your source file.
2. See the notes and action items below regarding this conversion run.
3. Check the rendered output (headings, lists, code blocks, tables) for proper
   formatting and use a linkchecker before you publish this page.

Conversion notes:

* Docs to Markdown version 1.0β17
* Tue Aug 27 2019 17:38:27 GMT-0700 (PDT)
* Source doc: https://docs.google.com/open?id=1i-EsNOdY1eFx5lveG_N8j4WhGXphkBqMAk07LcHMj0w
* This is a partial selection. Check to make sure intra-doc links work.
* This document has images: check for >>>>>  gd2md-html alert:  inline image link in generated source and store images to your server.
----->

![alt_text](images/TIF1000.png "image_tooltip")

<p align="center"><img src="images/assign.png"></p>


**Assignment 2:**

Using the two tools we’ve covered so far and your knowledge of the business need, decide which variables might be of importance to the problem we’re trying to solve and be prepared to explain your findings to upper management in a way that makes sense to them. Keep in mind none of them has any expeerince in this are so you’re going to need to get creative with your presentation and make it have business value and relevant to the problem.

<p align="center"><img src="images/pres.png"></p>



<!-- Docs to Markdown version 1.0β17 -->
